import sys
import os
import requests
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QTabWidget, QTableWidget, QTableWidgetItem
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QDragEnterEvent, QDropEvent
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

API_PROCESS = "http://127.0.0.1:5000/process"
API_URL = "http://127.0.0.1:5000/response"

# Widget to display the plot
class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig, self.ax = plt.subplots()
        super().__init__(fig)
        self.setParent(parent)

    def plot(self, data):
        self.ax.clear()
        self.ax.plot(data)
        self.draw()

# Widget to display the table
class TableView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.table = QTableWidget()
        self.layout = QVBoxLayout()
        self.layout.addWidget(self.table)
        self.setLayout(self.layout)

    def display_table(self, data):
        # Determine how many rows are needed
        num_rows = max(len([x for x in data if x["column"] == 1]), len([x for x in data if x["column"] == 2]))
        self.table.setRowCount(num_rows)
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(['fail', 'succeed'])

        # Track row positions for each column
        row_index = {1: 0, 2: 0}

        # Insert data into the appropriate columns - DID 
        for item in data:
            column = item.get("column")
            number = item.get("number")

            if column in row_index:
                row = row_index[column]
                self.table.setItem(row, column - 1, QTableWidgetItem(str(number)))
                row_index[column] += 1

# Main window for the application
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Drag and Drop File to Categorize Numbers")
        self.setGeometry(100, 100, 800, 600)

        # Enable drag and drop
        self.setAcceptDrops(True)

        # Create a label to instruct the user
        self.label = QLabel("Drag and drop a file with numbers", self)
        self.label.setAlignment(Qt.AlignCenter)

        # Create the tab widget
        self.tabs = QTabWidget(self)
        
        # Create PlotCanvas widget for the first tab
        self.plot_tab = QWidget()
        self.plot_canvas = PlotCanvas(self)
        plot_layout = QVBoxLayout()
        plot_layout.addWidget(self.plot_canvas)
        self.plot_tab.setLayout(plot_layout)

        # Create TableView widget for the second tab
        self.table_tab = QWidget()
        self.table_view = TableView(self)
        table_layout = QVBoxLayout()
        table_layout.addWidget(self.table_view)
        self.table_tab.setLayout(table_layout)

        # Add the tabs
        self.tabs.addTab(self.plot_tab, "Graph")
        self.tabs.addTab(self.table_tab, "Table")

        # Set layout
        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.tabs)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    # Handle drag events
    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    # Handle drop events
    def dropEvent(self, event: QDropEvent):
        urls = event.mimeData().urls()
        if urls:
            # Handle only the first file
            file_path = urls[0].toLocalFile()
            if os.path.isfile(file_path):
                self.load_file(file_path)

    # Load and process file content
    def load_file(self, file_path):
        try:
            # Read numbers from the file (assumes one number per line)
            with open(file_path, 'r') as file:
                numbers = [line.strip() for line in file]

            # Send numbers to the API
            response = requests.post(API_URL, json={"numbers": numbers})
            if response.status_code == 200:
                results = response.json()["results"]

                # Extract processed results for plotting
                processed_values = [float(item["number"]) for item in results if "number" in item]

                self.label.setText(f"Loaded file: {file_path}")
                # Plot the processed results on the plot tab
                self.plot_canvas.plot(processed_values)
                # Display the results in the table tab
                self.table_view.display_table(results)
            else:
                self.label.setText(f"Error processing file: {response.text}")

        except Exception as e:
            self.label.setText(f"Error loading file: {str(e)}")

# Main function to run the application
def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
