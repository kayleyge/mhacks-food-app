from flask import Flask, request, jsonify

app = Flask(__name__)
    

# Route to process a list of numbers
@app.route('/process', methods=['POST'])
def process():
    data = request.json
    numbers = data.get('numbers', [])
    results = []

    for i in range(0, numbers.size()):
        try:
            number = numbers[i]
            if bin(number) ==  0b001: #ack
                result = {"operation": "ack"}
            elif bin(number) ==  0b010:
                result= {"operation": "sts", "status": numbers[i+1]}
                i=i+1
            elif bin(number) ==  0b011:
                result= {"operation": "lvl"}
            elif bin(number) ==  0b100:
                result =  {"operation": "end"}
            results.append(result)

        except ValueError:
            results.append({"error": f"Invalid input: {numbers[i]}"})

    return jsonify({"results": results})

@app.route('/respond', methods=['GET'])
def response(fuel):
    results = []
    commands = process()
    for command in commands:
        if (command["operation"] == "ack"):
            result = {"result": 0b011}
            results.append(result)

        elif(command["operation"] == "sts" and command["status"] == 0b000):
            result = {"result": 0b011}
            results.append(result)

        elif(command["operation"] == "sts" and command["status"] = 0b011):
            result = {"result": 0b010}
            results.append(result)

        elif(command["operation"] == "end"):
            result = {"result": 0b011}
            results.append(result)

        elif(command["operation"] == "lvl"):
            result = {"result": fuel}
            results.append(result)
    return results
  

if __name__ == '__main__':
    app.run(debug=True)
